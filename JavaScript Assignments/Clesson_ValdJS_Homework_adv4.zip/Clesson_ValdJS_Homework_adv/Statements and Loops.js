//get year
const birth_year = 1999;
let current_year = new Date().getFullYear();
let age =  current_year - birth_year

//display age using only years
console.log (`Patient’s age: ${age}`);

//get Months
let birth_month = 8;
const current_month = new Date().getMonth();
current_year -= 1;
age =  current_year - birth_year;

if (birth_month <= current_month){
    age ++
}

//display age using year +- current month
console.log( `Patient’s Accurate Age: ${age}` )