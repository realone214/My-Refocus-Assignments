const width = 16;
const length = 20;

// area = length * width
let area = length * width;

console.log (`Width: ${width}`);
console.log (`Length: ${length}`);
console.log (`Area: ${area}`);