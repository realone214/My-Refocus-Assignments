let customer = {
    customer_name: "Johnny Manggo",
    points: 12300,
    cart: [
        {
            item: "Shampoo",
            quantity: 2,
            price_$: 3
        },

        {
            item: "Soap",
            quantity: 2,
            price_$: 2
        },

        {
            item: "Toothpaste",
            quantity: 1,
            price_$: 3
        }

    ]
}

//customer message
console.log(`Hi, ${customer.customer_name}! We are happy to see you today.`);
console.log(`Your current points is: ${customer.points}.`);
console.log("Purchased Items:");

//variables for purchase computation
let totalBill = 0;
let totalPoints = 0;

//loop for cart items
for (i=0; i<customer.cart.length; i++){
    console.log(`${customer.cart[i].quantity}x ${customer.cart[i].item} ---- $ ${customer.cart[i].price_$.toFixed(2)}`);
    totalBill += customer.cart[i].price_$ * customer.cart[i].quantity;
    totalPoints += customer.cart[i].quantity;
}

console.log(`Total Bill: $ ${totalBill.toFixed(2)}`);
console.log(`New Current Points: ${totalPoints + customer.points}`);




