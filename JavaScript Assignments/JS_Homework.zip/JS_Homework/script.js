let firstName = "Clesson";
let lastName = "valdez";
const msg = `Hello, ${firstName} ${lastName}! How can we help you today?`

console.log (msg)